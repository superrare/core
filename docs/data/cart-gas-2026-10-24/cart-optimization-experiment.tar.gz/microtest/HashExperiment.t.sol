// SPDX-License-Identifier: MIT
pragma solidity 0.8.18;
import "forge-std/Test.sol";
import {ICart} from "../src/cart/ICart.sol";
import {HashBaseline} from "../microsrc/HashBaseline.sol";
import {HashOptimized} from "../microsrc/HashOptimized.sol";
contract HashBaseWrapper { function hash(ICart.OrderLine[] calldata lines) external pure returns(bytes32) {return HashBaseline.hashOrderLines(lines);} }
contract HashOptWrapper { function hash(ICart.OrderLine[] calldata lines) external pure returns(bytes32) {return HashOptimized.hashOrderLines(lines);} }
contract HashExperimentTest is Test {
    HashBaseWrapper base;
    HashOptWrapper opt;
    event HashMeasured(uint256 count, uint256 baseline, uint256 optimized);
    function setUp() public { base=new HashBaseWrapper();opt=new HashOptWrapper(); }
    function testHash1() public {_measure(1);}
    function testHash10() public {_measure(10);}
    function testHash20() public {_measure(20);}
    function testHash32() public {_measure(32);}
    function _measure(uint256 count) internal {
        ICart.OrderLine[] memory lines=_lines(bytes32(uint256(17)),count);
        uint256 g=gasleft(); bytes32 a=base.hash(lines);uint256 usedBase=g-gasleft();
        g=gasleft();bytes32 b=opt.hash(lines);uint256 usedOpt=g-gasleft();
        assertEq(a,b);emit HashMeasured(count,usedBase,usedOpt);
    }
    function testFuzzHashEquivalent(bytes32 seed,uint8 rawCount) public {
        ICart.OrderLine[] memory lines=_lines(seed,uint256(rawCount)%129);
        assertEq(base.hash(lines),opt.hash(lines));
    }
    function testRawMalformedFieldEquivalence() public {
        ICart.OrderLine[] memory lines=_lines(bytes32(uint256(17)),1);
        for(uint256 field;field<3;++field) {
            bytes memory payload=abi.encodeWithSelector(base.hash.selector,lines);
            uint256 offset=field==0?132:(field==1?196:260);
            uint256 value=field==0?255:(uint256(1)<<200)|17;
            assembly ("memory-safe") {mstore(add(add(payload,32),offset),value)}
            (bool a,bytes memory ar)=address(base).staticcall(payload);
            (bool b,bytes memory br)=address(opt).staticcall(payload);
            assertEq(a,b); assertEq(ar,br);
        }
    }
    function _lines(bytes32 seed,uint256 count) internal pure returns(ICart.OrderLine[] memory lines) {
        lines=new ICart.OrderLine[](count);
        for(uint256 i;i<count;++i) {
            bytes32 h=keccak256(abi.encode(seed,i));
            lines[i]=ICart.OrderLine(h,keccak256(abi.encode(h)),ICart.FulfillmentKind(uint256(h)%7),uint256(h),address(uint160(uint256(h))),uint256(h),address(uint160(uint256(keccak256(abi.encode(h))))));
        }
    }
}
