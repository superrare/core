// SPDX-License-Identifier: MIT
pragma solidity 0.8.18;
import "forge-std/Test.sol";
import {ICart} from "../src/cart/ICart.sol";
contract PayoutBaseline {
    uint256 constant NO_GROUP = type(uint256).max;
    struct Payout { address token; address recipient; uint256 amount; uint256 lineIndex; bool native; }
    function group(ICart.OrderLine[] calldata lines) external pure returns (Payout[] memory) {
        address wrappedNative = address(1);
        Payout[] memory payouts = new Payout[](lines.length);
        uint256 count;
        for (uint256 i = 0; i < lines.length; ++i) {
            bool native = lines[i].settlementCurrency == address(0);
            address token = native ? wrappedNative : lines[i].settlementCurrency;
            uint256 payoutIndex = NO_GROUP;
            for (uint256 j = 0; j < count; ++j) {
                if (
                    payouts[j].token == token && payouts[j].recipient == lines[i].paymentRecipient
                        && payouts[j].native == native
                ) {
                    payoutIndex = j;
                    break;
                }
            }
            if (payoutIndex == NO_GROUP) {
                payoutIndex = count++;
                payouts[payoutIndex] = Payout({
                    token: token, recipient: lines[i].paymentRecipient, amount: 0, lineIndex: i, native: native
                });
            }
            payouts[payoutIndex].amount += lines[i].amount;
        }

        assembly ("memory-safe") { mstore(payouts, count) }
        return payouts;
    }
}
contract PayoutOptimized {
    uint256 constant NO_GROUP = type(uint256).max;
    struct Payout { address token; address recipient; uint256 amount; uint256 lineIndex; bool native; }
    function group(ICart.OrderLine[] calldata lines) external pure returns (Payout[] memory) {
        address wrappedNative = address(1);
        Payout[] memory payouts = new Payout[](lines.length);
        uint256 tableSize = 1;
        while (tableSize < lines.length * 2) tableSize <<= 1;
        uint256[] memory slots = new uint256[](tableSize);
        uint256 mask = tableSize - 1;
        uint256 count;
        for (uint256 i; i < lines.length; ++i) {
            bool native = lines[i].settlementCurrency == address(0);
            address token = native ? wrappedNative : lines[i].settlementCurrency;
            address recipient = lines[i].paymentRecipient;
            uint256 slot = uint256(keccak256(abi.encode(token, recipient, native))) & mask;
            uint256 payoutIndex = NO_GROUP;
            while (slots[slot] != 0) {
                uint256 candidate = slots[slot] - 1;
                if (payouts[candidate].token == token && payouts[candidate].recipient == recipient
                    && payouts[candidate].native == native) {
                    payoutIndex = candidate;
                    break;
                }
                slot = (slot + 1) & mask;
            }
            if (payoutIndex == NO_GROUP) {
                payoutIndex = count++;
                slots[slot] = payoutIndex + 1;
                payouts[payoutIndex] = Payout({
                    token: token, recipient: recipient, amount: 0, lineIndex: i, native: native
                });
            }
            payouts[payoutIndex].amount += lines[i].amount;
        }

        assembly ("memory-safe") { mstore(payouts, count) }
        return payouts;
    }
}

contract PayoutExperimentTest is Test {
    PayoutBaseline base;
    PayoutOptimized opt;
    event Measured(uint256 count, uint256 baseline, uint256 optimized);
    function setUp() public { base = new PayoutBaseline(); opt = new PayoutOptimized(); }
    function testGroup1() public { _measure(1); }
    function testGroup10() public { _measure(10); }
    function testGroup20() public { _measure(20); }
    function testGroup32() public { _measure(32); }
    function _measure(uint256 count) internal {
        ICart.OrderLine[] memory lines = new ICart.OrderLine[](count);
        for (uint256 i; i < count; ++i) {
            lines[i].paymentRecipient = address(uint160(i+1000)); lines[i].amount = i+1;
        }
        uint256 g=gasleft();
        bytes memory a=abi.encode(base.group(lines));
        uint256 usedBase=g-gasleft();
        g=gasleft();
        bytes memory b=abi.encode(opt.group(lines));
        uint256 usedOpt=g-gasleft();
        assertEq(a,b);
        emit Measured(count, usedBase, usedOpt);
    }
    event SharedMeasured(uint256 count, uint256 groups, uint256 baseline, uint256 optimized);
    function testShared1Groups9Lines() public { _measureShared(9,1); }
    function testShared2Groups9Lines() public { _measureShared(9,2); }
    function testShared1Groups19Lines() public { _measureShared(19,1); }
    function testShared2Groups19Lines() public { _measureShared(19,2); }
    function testShared1Groups32Lines() public { _measureShared(32,1); }
    function testShared2Groups32Lines() public { _measureShared(32,2); }
    function testShared1Groups64Lines() public { _measureShared(64,1); }
    function testShared2Groups64Lines() public { _measureShared(64,2); }
    function _measureShared(uint256 count,uint256 groups) internal {
        ICart.OrderLine[] memory lines = new ICart.OrderLine[](count);
        for (uint256 i; i < count; ++i) {
            lines[i].paymentRecipient = address(uint160(i%groups+1000)); lines[i].amount = i+1;
        }
        uint256 g=gasleft();
        bytes memory a=abi.encode(base.group(lines));
        uint256 usedBase=g-gasleft();
        g=gasleft();
        bytes memory b=abi.encode(opt.group(lines));
        uint256 usedOpt=g-gasleft();
        assertEq(a,b);
        emit SharedMeasured(count,groups,usedBase,usedOpt);
    }
    function testFuzzGroupEquivalent(bytes32 seed, uint8 rawCount) public {
        uint256 count=uint256(rawCount)%129;
        ICart.OrderLine[] memory lines = new ICart.OrderLine[](count);
        for (uint256 i; i < count; ++i) {
            bytes32 h=keccak256(abi.encode(seed,i));
            lines[i].paymentRecipient=address(uint160(uint256(h)%16));
            lines[i].settlementCurrency=address(uint160(uint256(h)%3));
            lines[i].amount=uint256(h)%1e18;
        }
        assertEq(abi.encode(base.group(lines)),abi.encode(opt.group(lines)));
    }
}
