Cart optimization experiment, October 24, 2026

This bundle contains the exact temporary source and fixtures for 16 baseline and 16 payout-only optimized purchase scenarios. No production files were changed. The temporary Cart line cap is 128 so the 64-line cases execute. The fulfillment cap remains 20. The current source CartPayments.sol is the optimized variant. CartPayments.baseline.sol is the unmodified working-tree baseline.

Reproduction requires Forge 1.4.3, Solidity 0.8.18, and the repository's lib dependencies. Create a lib symlink in the extracted directory pointing to superrare-core/lib. Run forge from the extracted directory.

Baseline full purchases:
cp CartPayments.baseline.sol src/cart/CartPayments.sol
forge test --offline --match-contract CartGasCapacityTest -vvvv

Payout-only optimized full purchases:
cp payout-candidate.txt src/cart/CartPayments.sol
forge test --offline --match-contract CartGasCapacityTest -vvvv

Differential and microbenchmarks:
FOUNDRY_SRC=microsrc FOUNDRY_TEST=microtest FOUNDRY_OUT=microout FOUNDRY_CACHE_PATH=microcache forge test --offline -vvvv

The baseline and payout-full logs retain the measured Capacity events. optimization-results.json records the extracted figures and qualifications. The patches describe the two candidates separately. Payout grouping has 256 differential fuzz cases with 0 through 128 lines, repeated recipients, and mixed currencies. Order-line hashing has 256 differential fuzz cases and malformed field comparisons. The full purchase scenarios cover distinct native payout recipients, separate singleton seller roots, depth-64 proofs at 20 and 32 lines, and local ERC-721 mint mocks at 20 operations.

The approximation is max(grossCallGas + ordinaryIntrinsicGas, calldataFloorGas). This is not a transaction receipt or a live NFT gas guarantee. Deliberately colliding hash buckets can still produce quadratic lookup cost. First-seen payout order, the native form, amounts, and first line indexes are preserved.

The additional payout-shared-micro.log measures one and two payout groups at 9, 19, 32, and 64 lines. All eight cases pass. They show that unconditional hash-table grouping adds gas for these common workloads. Use an adaptive strategy or retain the existing scan until that tradeoff is resolved.
